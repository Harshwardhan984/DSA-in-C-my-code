#include <stdio.h>
#include <stdlib.h>

void bubbleSort(int *arr, int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

void printArray(int *arr, int n) {
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main() {
    int n = 7;
    int *arr = (int *)malloc(n * sizeof(int));
    arr[0] = 64; arr[1] = 34; arr[2] = 25; arr[3] = 12; arr[4] = 22; arr[5] = 11; arr[6] = 90;

    bubbleSort(arr, n);
    printArray(arr, n);

    free(arr);
    return 0;
}

