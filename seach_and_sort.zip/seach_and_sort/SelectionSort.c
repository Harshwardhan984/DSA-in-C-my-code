#include <stdio.h>
#include <stdlib.h>

void selectionSort(int *arr, int n) {
    for (int i = 0; i < n - 1; i++) {
        int min_idx = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[min_idx]) {
                min_idx = j;
            }
        }
        int temp = arr[min_idx];
        arr[min_idx] = arr[i];
        arr[i] = temp;
    }
}

void printArray(int *arr, int n) {
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main() {
    int n = 7;
    int *arr = (int *)malloc(n * sizeof(int));
    arr[0] = 64; arr[1] = 34; arr[2] = 25; arr[3] = 12; arr[4] = 22; arr[5] = 11; arr[6] = 90;

    selectionSort(arr, n);
    printArray(arr, n);

    free(arr);
    return 0;
}

