#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void binarySearch(int *arr, int n, int key) {
    int low = 0, high = n - 1, mid, found = 0;
    while (low <= high) {
        mid = low + (high - low) / 2;
        if (arr[mid] == key) {
            printf("Key found at index %d\n", mid);
            found = 1;
            break;
        } else if (arr[mid] < key) {
            low = mid + 1;
        } else {
            high = mid - 1;
        }
    }
    if (!found) {
        printf("Key not found\n");
    }
}

int main() {
    int n = 7;
    int *arr = (int *)malloc(n * sizeof(int));
    arr[0] = 1; arr[1] = 2; arr[2] = 3; arr[3] = 5; arr[4] = 6; arr[5] = 8; arr[6] = 9;
    int key = 8;

    clock_t start = clock();
    binarySearch(arr, n, key);
    clock_t end = clock();

    double time_taken = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Time taken: %f seconds\n", time_taken);

    free(arr);
    return 0;
}

