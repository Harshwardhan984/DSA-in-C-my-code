#include <stdio.h>
#include <stdlib.h>

void quickSort(int *arr, int low, int high) {
    if (low < high) {
        int pivot = arr[high], i = low - 1;
        for (int j = low; j < high; j++) {
            if (arr[j] <= pivot) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        int pi = i + 1;
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

void printArray(int *arr, int n) {
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main() {
    int n = 7;
    int *arr = (int *)malloc(n * sizeof(int));
    arr[0] = 64; arr[1] = 34; arr[2] = 25; arr[3] = 12; arr[4] = 22; arr[5] = 11; arr[6] = 90;

    quickSort(arr, 0, n - 1);
    printArray(arr, n);

    free(arr);
    return 0;
}

