#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void linearSearch(int *arr, int n, int key) {
    int found = 0;
    for (int i = 0; i < n; i++) {
        if (arr[i] == key) {
            printf("Key found at index %d\n", i);
            found = 1;
            break;
        }
    }
    if (!found) {
        printf("Key not found\n");
    }
}

int main() {
    int n = 7;
    int *arr = (int *)malloc(n * sizeof(int));
    arr[0] = 5; arr[1] = 3; arr[2] = 8; arr[3] = 6; arr[4] = 1; arr[5] = 9; arr[6] = 2;
    int key = 8;

    clock_t start = clock();
    linearSearch(arr, n, key);
    clock_t end = clock();

    double time_taken = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Time taken: %f seconds\n", time_taken);

    free(arr);
    return 0;
}

