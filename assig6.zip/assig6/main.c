// main.c
#include <stdio.h>
#include <stdlib.h>
#include "heap.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    FILE *file = fopen(argv[1], "r");
    if (file == NULL) {
        printf("Could not open file %s\n", argv[1]);
        return 1;
    }

    // Initialize heap
    Heap heap;
    heap.size = 0;
    heap.data = NULL;

    // Read numbers into the heap's data array
    int num;
    while (fscanf(file, "%d", &num) == 1) {
        heap.data = realloc(heap.data, (heap.size + 1) * sizeof(int));
        heap.data[heap.size++] = num;
    }
    fclose(file);

    if (heap.size == 0) {
        printf("No integers found in the file.\n");
        free(heap.data);
        return 1;
    }

    // Sort using heap sort
    heapSort(&heap);

    // Display sorted numbers
    printf("Sorted integers:\n");
    for (int i = 0; i < heap.size; i++) {
        printf("%d ", heap.data[i]);
    }
    printf("\n");

    free(heap.data);
    return 0;
}

