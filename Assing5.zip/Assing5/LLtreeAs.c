#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include<limits.h>
#include "LLtreeAs.h" 

int main(){
	BST t;
	initBST(&t);
	
//Perform a series of insertions on keys - December, January, April, March, July, August, October, February, November, May, June.  
	insertNode(&t,"December");
	
	insertNode(&t,"January");
	
	insertNode(&t,"April");
	
	insertNode(&t,"March");
	
	insertNode(&t,"July");
	
	insertNode(&t,"August");
	
	insertNode(&t,"October");

	insertNode(&t,"February");
	
	insertNode(&t,"November");
	
	insertNode(&t,"May");

	insertNode(&t,"June");
	
	
	non_recursive_preorder(t);
	printf("\n");
	non_recursive_inorder(t);
	printf("\n");
	non_recursive_postorder(t);
	printf("\n");
	
	node* p = searchNode(&t, "December");
	printf("%s \n", p->month);
	
	removeNode(&t, "December");
	
	non_recursive_preorder(t);
	printf("\n");
	
	removeNode(&t, "November");
	
	non_recursive_preorder(t);
	printf("\n");
	
	
	removeNode(&t, "May");
	
	non_recursive_preorder(t);
	printf("\n");
	
	removeNode(&t, "March");
	
	non_recursive_preorder(t);
	printf("\n");
	
	removeNode(&t, "January");
	
	non_recursive_preorder(t);
	printf("\n");
	
	removeNode(&t, "August");
	
	non_recursive_preorder(t);
	printf("\n");
	
	removeNode(&t, "June");
	
	non_recursive_preorder(t);
	printf("\n");
	
	removeNode(&t, "April");
	
	non_recursive_preorder(t);
	printf("\n");
	
	removeNode(&t, "February");
	
	non_recursive_preorder(t);
	printf("\n");
	
	removeNode(&t, "July");
	
	non_recursive_preorder(t);
	printf("\n");
	
	removeNode(&t, "October");
	
	non_recursive_preorder(t);
	printf("\n");
	
	removeNode(&t, "November");
	
	non_recursive_preorder(t);
	printf("\n");
	
	insertNode(&t,"March");
	
	insertNode(&t,"July");
	
	insertNode(&t,"August");
	
	insertNode(&t,"October");

	insertNode(&t,"February");
	
	insertNode(&t,"November");
	
	insertNode(&t,"May");
	
	non_recursive_preorder(t);
	printf("\n");
	non_recursive_inorder(t);
	printf("\n");
	non_recursive_postorder(t);
	printf("\n");
	
	
	destroyTree(&t);
	
	non_recursive_preorder(t);
	printf("\n");
	
	return 0;
}
