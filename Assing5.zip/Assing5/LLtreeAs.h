// Assingment 5

typedef struct node{
    char month[15];
    struct node *lchild;
    struct node  *rchild;
}node;


// stack
// Define the structure for a stack node
typedef struct StackNode {
    node* data;  // Pointer to tree node
    struct StackNode* next;
} StackNode;

// Define the structure for the stack
typedef struct Stack {
    StackNode* top;
} Stack;

void initStack(Stack* s);
void push(Stack* s, node* node);
int isEmpty(Stack* s);
node* pop(Stack* s);
node* peek(Stack* s);




// Tree(BST) using LL
/*
initBST()         // to initialize the tree. 

insertNode()    // non-recursive function to add a new node to the BST. 

removeNode() // to remove a node from a tree. 

traverse()         // write any of the non-recursive traversal methods.

destroyTree()  // to delete all nodes of a tree.

Write a menu driven program to invoke all above functions.  
*/


typedef struct node* BST;

void initBST(BST *t);
void insertNode(BST *t, const char *d);
node* searchNode(BST *t, const char *d);
node* getSuccessor(node* curr);
node* removeNode(BST *t, const char *d);

void non_recursive_preorder(BST t);

void non_recursive_inorder(BST t);

void non_recursive_postorder(BST t);
void destroyTree(BST *t); 
