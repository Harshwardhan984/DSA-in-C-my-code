/*
Implement ADT Binary Search Tree(BST) using a linked list of nodes of structure having Month, left pointer, right pointer, and parent pointers pointing to left sub-trees, right sub-tree, and parent of the node.

Perform a series of insertions on keys - December, January, April, March, July, August, October, February, November, May, June.  Write following functions: 

initBST()         // to initialize the tree. 

insertNode()    // non-recursive function to add a new node to the BST. 

removeNode() // to remove a node from a tree. 

traverse()         // write any of the non-recursive traversal methods.

destroyTree()  // to delete all nodes of a tree.

Write a menu driven program to invoke all above functions.  
*/

#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include<limits.h>
#include "LLtreeAs.h" 

// Initialize the stack
void initStack(Stack* s) {
    s->top = NULL;
    return;
}

// Push a tree node onto the stack
void push(Stack* s, node* node) {
    StackNode* newStackNode = (StackNode*)malloc(sizeof(StackNode));
    newStackNode->data = node;
    newStackNode->next = s->top;
    s->top = newStackNode;
    return;
}

// Check if the stack is empty
int isEmpty(Stack* s) {
    return s->top == NULL;
}

// Pop a node from the stack
node* pop(Stack* s) {
    if (isEmpty(s)) {
        return NULL;
    }
    StackNode* temp = s->top;
    node* node = temp->data;
    s->top = s->top->next;
    free(temp);
    return node;
}

node* peek(Stack* s){
	if (isEmpty(s)) {
        return NULL;
    }
    return s->top->data;
}

// tree function
void initBST(BST *t){
    *t=NULL;
    return;
}

void insertNode(BST *t, const char* d){
    node *nn=(BST)malloc(sizeof(node));
    strcpy(nn->month, d);
    nn->lchild=nn->rchild=NULL;
    if(*t==NULL){
        *t=nn;
        return;
    }
    node *p=*t,*q=NULL;
    while(p){
        q=p;
        if(strcmp(p->month , d) > 0)
            p=p->lchild;
        else if(strcmp(p->month , d) < 0)
            p=p->rchild;
        else{
            free(nn);
            return;
        }
    }
    if(strcmp(q->month , d) > 0)
        q->lchild=nn;
    else if(strcmp(q->month , d) < 0)
        q->rchild=nn;
    return;

}

node* searchNode(BST *t, const char *d){
	 if(*t==NULL){
        return NULL;
    }
    node *p=*t;
    while(p && strcmp(p->month, d) != 0){
       
        if(strcmp(p->month , d) > 0)
            p=p->lchild;
        else if(strcmp(p->month , d) < 0)
            p=p->rchild;
    }
    return p;
}

node* getSuccessor(node* curr){
    curr = curr->rchild;
    while (curr != NULL && curr->lchild != NULL)
        curr = curr->lchild;
    return curr;
}

node* removeNode(BST *t, const char *d){
if (*t == NULL)
        return *t;

    node *p = searchNode(t, d);
    
    if (p == NULL)  // Node not found
        return *t;

    // Case 1: Node to be deleted is a leaf
    if (p->lchild == NULL && p->rchild == NULL) {
        if (p == *t) { // If the node is the root
            free(p);
            *t = NULL;
        } else {
            node *q = *t;
            while (q) {
                if (q->lchild == p) {
                    free(p);
                    q->lchild = NULL;
                    break;
                } else if (q->rchild == p) {
                    free(p);
                    q->rchild = NULL;
                    break;
                } else if (strcmp(q->month, d) > 0) {
                    q = q->lchild;
                } else {
                    q = q->rchild;
                }
            }
        }
    }
    // Case 2: Node has only a right child
    else if (p->lchild == NULL && p->rchild != NULL) {
        if (p == *t) { // Node is the root
            *t = p->rchild;
        } else {
            node *q = *t;
            while (q) {
                if (q->lchild == p) {
                    q->lchild = p->rchild;
                    break;
                } else if (q->rchild == p) {
                    q->rchild = p->rchild;
                    break;
                } else if (strcmp(q->month, d) > 0) {
                    q = q->lchild;
                } else {
                    q = q->rchild;
                }
            }
        }
        free(p);
    }
    // Case 3: Node has only a left child
    else if (p->lchild != NULL && p->rchild == NULL) {
        if (p == *t) { // Node is the root
            *t = p->lchild;
        } else {
            node *q = *t;
            while (q) {
                if (q->lchild == p) {
                    q->lchild = p->lchild;
                    break;
                } else if (q->rchild == p) {
                    q->rchild = p->lchild;
                    break;
                } else if (strcmp(q->month, d) > 0) {
                    q = q->lchild;
                } else {
                    q = q->rchild;
                }
            }
        }
        free(p);
    }
	
	else
	{
		node* succ = getSuccessor(p);  // Get in-order successor
       		 strcpy(p->month, succ->month);  // Copy the successor's value
        		// Recursively delete the successor node
        	p->rchild = removeNode(&(p->rchild), succ->month);
		
	}
	return *t;
}


void non_recursive_preorder(BST t){
	
    if (t == NULL) {
        return;
    }
    node *p = t;
    Stack s;
    initStack(&s);
    while (p || !isEmpty(&s)) {
    	if(p){
    		printf("%s -> ",p->month);
    		push(&s,p);
    		p=p->lchild;
    	}
    	else{
    		p = pop(&s);
    		p = p->rchild;
    	}      
}
return;
}


void non_recursive_inorder(BST t){
	
    if (t == NULL) {
        return;
    }
    node *p = t;
    Stack s;
    initStack(&s);
    while (p || !isEmpty(&s)) {
    	if(p){
    		//printf("%d->",p->data);
    		push(&s,p);
    		p=p->lchild;
    	}
    	else{	
    		p = pop(&s);
    		printf("%s -> ",p->month);
    		p = p->rchild;
    	}      
}
return;
}


void non_recursive_postorder(BST t){
	
    if (t == NULL) {
        return;
    }
    Stack s1, s2;
    initStack(&s1);
    initStack(&s2);
    
    push(&s1, t);
    
    while (!isEmpty(&s1)) {
        node *p = pop(&s1);
        push(&s2, p);
        
        // Push left and right children into s1
        if (p->lchild) {
            push(&s1, p->lchild);
        }
        if (p->rchild) {
            push(&s1, p->rchild);
        }
    }
    
    // Now print all nodes from s2 which are in post-order
    while (!isEmpty(&s2)) {
        node *p = pop(&s2);
        printf("%s -> ", p->month);
    }
    
    return;
}


void destroyTree(BST *t){
	if(!*t)
		return;
	destroyTree(&((*t) -> lchild));
	destroyTree(&((*t) -> rchild));
	
	free(*t);
	*t = NULL;
}






