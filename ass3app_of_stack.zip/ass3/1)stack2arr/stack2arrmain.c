#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "stack2arr.h"

int main() {
	sk S1;
	init(&S1);
	Push1(&S1, 1);
	Push1(&S1, 2);
	Push1(&S1, 3);
	Push1(&S1, 4);
	Push1(&S1, 5);
	print_stack(S1);
	printf("%d\n",Pop1(&S1));
	printf("%d\n",Peek1(S1));
	print_stack(S1);
	Push2(&S1, 11);
	Push2(&S1, 12);
	Push2(&S1, 13);
	Push2(&S1, 14);
	Push2(&S1, 15);
	print_stack(S1);
	printf("%d\n",Pop2(&S1));
	printf("%d\n",Peek2(S1));
	print_stack(S1);
	
	return 0;
}
