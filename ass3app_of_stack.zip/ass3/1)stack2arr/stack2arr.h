typedef struct stack{
	int size1, top1;
	int size2, top2;
	int * arr;
}stack;

typedef stack sk;

void init(sk* s);
int isEmpty1(sk s);
int isEmpty2(sk s);
void Push1(sk* s, int d);
int Pop1(sk* s);
int Peek1(sk s);
void Push2(sk* s, int d);
int Pop2(sk* s);
int Peek2(sk s);
void print_stack(sk s);
