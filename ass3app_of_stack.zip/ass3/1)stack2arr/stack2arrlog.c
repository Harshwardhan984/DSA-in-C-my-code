#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "stack2arr.h"

void init(sk* s){
	s->size1 = 10;
	s->top1 = -1;
	s->size2 = 20;
	s->top2 = -1;
	s->arr = (int*)malloc(sizeof(int) * (s->size1 + s->size2 ));
	return;
}

int isEmpty1(sk s){
	if(s.top1 == -1)
		return 1;
	else 
		return 0;
} 
int isEmpty2(sk s){
	if(s.top2 == -1)
		return 1;
	else 
		return 0;
} 

void Push1(sk* s, int d){
	if(s->top1 == (s->size1 - 1)){
		printf("stack is full");
		return;
	}
	else{
		s->top1++;
		s->arr[s->top1] = d;
		return;
	}
}

int Pop1(sk* s){
	if(s->top1 == -1){
		printf("stack is empty");
		return -1;
	}
	else{
		int tem = s->arr[s->top1];
		s->top1--;
		return tem;
		
	}
}

int Peek1(sk s){
	if(s.top1 == -1){
		printf("stack is empty");
		return -1;
	}
	else
		return s.arr[s.top1] ;
}

void Push2(sk* s, int d){
	if(s->top2 == (s->size1 + s->size2 - 1)){
		printf("stack is full");
		return;
	}
	else{
		if(s->top2 == -1){
			s->top2 = s->size1;
			s->arr[s->top2] = d;
			return;
		}
		else{
			s->top2++;
			s->arr[s->top2] = d;
			return;
			}
	}
}

int Pop2(sk* s){
	if(s->top2 == -1){
		printf("stack2 is empty");
		return -1;
	}
	else{
		if(s->top2 == s->size1){
			int tem = s->arr[s->top2];
			s->top2 = -1;
			return tem;
		}
		else{
			int tem = s->arr[s->top2];
			s->top2--;
			return tem;
		}
		
	}
}

int Peek2(sk s){
	if(s.top2 == -1){
		printf("stack is empty");
		return -1;
	}
	else
		return s.arr[s.top2] ;
}


void print_stack(sk s){
	int i = 0;
	printf("stack 1\n");
	while(i <= s.top1){
		printf("%d ", s.arr[i]);
		i++;
	}
	i = s.size1;
	printf("\n");
	printf("stack 2\n");
	while(i <= s.top2){
		printf("%d ", s.arr[i]);
		i++;
	}
	printf("\n");
	return;
}
	

