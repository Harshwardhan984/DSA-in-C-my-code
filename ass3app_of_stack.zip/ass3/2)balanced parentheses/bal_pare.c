#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <stdbool.h>
#include "bal_pare.h"

int main(){
	char I[50];
	bool ans = false;
	scanf("%s",I);
	stack s;
	init(&s, strlen(I));
	int i = 0;
	char c;
	while(I[i] != '\0'){
		c = I[i];
		if(c == '(' || c == '{' || c == '['){
			if(isEmpty(s))
				Push(&s, c);
			else if(isMorePare(c, Peek(s))){
				ans = false;
				break;
			}
			else
				Push(&s, c);
			
		}
		else{
			if(isEmpty(s)){
				ans = false;
				break;
			}
			if(c == ')'){
				if(Peek(s) == '(')
					Pop(&s);
				else{
					ans = false;
					break;
				}
			}
			else if(c == ']'){
					if(Peek(s) == '[')
						Pop(&s);
					else{
						ans = false;
						break;
					}
				}
			else {
				if(Peek(s) == '{')
						Pop(&s);
					else{
						ans = false;
						break;
					}
			}
			
		}
		i++;
	}
	if(I[i] == '\0' && isEmpty(s))
		ans = true;
	else
		ans = false;
	printf("if ans = 1 then true ,\nor if ans = 0 then false\n");
	printf("ans : %d\n",ans);
	return 0;
}
