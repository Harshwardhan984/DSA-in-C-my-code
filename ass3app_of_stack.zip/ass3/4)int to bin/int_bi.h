typedef struct stack{
	int size, top;
	char * arr;
}stack;

typedef stack sk;

void init(sk* s, int n);

int isEmpty(sk s);
int isFull(sk s);
void Push(sk* s, char d);
char Pop(sk* s);
char Peek(sk s);
void print_stack(sk s);
