#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <stdbool.h>
#include "int_bi.h"

int main(){
	int num;
	scanf("%d",&num);
	char B[32];
	char c;
	stack s;
	init(&s,32);
	int i=0, tem=num;
	
	while(num != 0){
		if(num%2 == 0)
			c = '0';
		else
			c = '1';
		Push(&s,c);
		num=num/2;
	}
	
	while(!isEmpty(s)){
		B[i] = Pop(&s);
		i++;
	}
	i--;
	while(i>=0){
		Push(&s,B[i]);
		i--;
	}
	while(!isFull(s)){
		Push(&s,'0');
	}
	if(tem>=0){
		i = 0;
		while(!isEmpty(s)){
			B[i] = Pop(&s);
			i++;
		}
	}
	else{
		i=0;
		while(!isEmpty(s)){
			c = Pop(&s);
			if(c == '1')
				B[i] = '0';
			else
				B[i] = '1';
			i++;
		}
		i--;
		while(i>=0){
			if(B[i] == '0'){
				B[i] = '1';
				break;
			}
			else{
				B[i] = '0';
				i--;
			}
		}
	}
	printf("%s\n",B);
	return 0;
}
