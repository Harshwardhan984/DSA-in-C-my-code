#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <stdbool.h>
#include "revstr.h"

int main(){
	char I[100];
	fgets(I, sizeof(I), stdin);  
	char O[100];
	stack s;
	init(&s, strlen(I));
	int i = 0;
	char c;
	while(I[i] != '\0'){
		c = I[i];
		Push(&s,c);
		i++;
	}
	i=0;
	while(!isEmpty(s)){
		
		O[i] = Pop(&s);
		i++;
	}
	O[i] = '\0';
	printf("%s\n",O);
	
	return 0;
}
