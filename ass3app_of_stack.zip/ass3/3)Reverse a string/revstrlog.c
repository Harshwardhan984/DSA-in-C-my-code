#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <stdbool.h>
#include "revstr.h"

void init(sk* s, int n){
	s->size = n;
	s->top = -1;
	s->arr = (char*)malloc(sizeof(char) * s->size);
	return;
}




int isEmpty(sk s){
	if(s.top == -1)
		return 1;
	else 
		return 0;
} 



void Push(sk* s, char d){
	if(s->top == (s->size - 1)){
		printf("stack is full");
		return;
	}
	else{
		s->top++;
		s->arr[s->top] = d;
		return;
	}
}

char Pop(sk* s){
	if(s->top == -1){
		printf("stack is empty");
		return '\0';
	}
	else{
		char tem = s->arr[s->top];
		s->top--;
		return tem;
		
	}
}

char Peek(sk s){
	if(s.top == -1){
		printf("stack is empty");
		return '\0';
	}
	else
		return s.arr[s.top] ;
}

void print_stack(sk s){
	int i = 0;
	while(i <= s.top){
		printf("%c ", s.arr[i]);
		i++;
	}
	printf("\n");
	return;
}
	

