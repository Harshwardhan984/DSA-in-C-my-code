
#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include "queue.h"

//qinit, enq, deq, qfull, qempty;

void qinit(queue *q){
	q ->head = NULL;
	q->tail = NULL;
	return;
}

int qfull(queue *q){
	 node* testNode = ( node*)malloc(sizeof( node));
    if (testNode == NULL) {
        return 1; 
    } else {
        free(testNode); 
        return 0;  
    }
}

int qempty(queue *q){
	if(q->head == NULL && q->tail == NULL)
		return 1;
	return 0;
}


void enq(queue *q, data d){
	if(qfull(q))
		return;
	node * nn = (node*)malloc(sizeof(node));
	nn->d = d;
	if(nn == NULL)
		return;
	else{
		if(qempty(q)){
			q->head = nn;
			q->tail = nn;
			nn->next = q->head;
		}
		else{
			q->tail->next = nn;
			q->tail = q->tail->next;
			nn->next = q->head;
		}
		
	}
	return;
}


data deq(queue *q){
	if(qempty(q)){
		data tem;
		tem.name[0] = '\0';
		tem.age = 0;
		printf("queue is emty\n");
		return tem;
	}
		
	else{
		if(q->head == q->tail){
			data tem;
			tem = q->head->d;
			node *p = q->head;
			q->head = NULL;
			q->tail = NULL;
			free(p);
			return tem;
		}
		else{
		data tem;
		tem = q->head->d;
		node *p = q->head;
		q->head = p->next;
		q->tail->next = q->head;
		free(p);
		return tem;
		}
		
	}
}






